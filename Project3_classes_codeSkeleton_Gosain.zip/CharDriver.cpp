// CSCI 1300 Fall 2020
// Author: Vanshita Gosain
// Recitation: 324
// Project 3

#include "Chardriver.h"
#include "Character.h"
#include <vector>
#include <string>

using namespace std;

CharDriver::CharDriver()
{
    // initialize varaiables
}
// Create a while loop menu that prompts character names
// User can choose which characters they want to know about util they select quit.
void print_character_menu() {
            for (int i = 0; i < characters.size(); i++) 
            {
                cout << i << ": " << characters[i]getName();
            }
        }

// Populates the vecttor name and prints out the character name and thei background.
void populate_characters() {
        Character marty = Character("Marty", "Marty McFly is...");
        Character george = Character("George", "George McFly is...");
        Character docBrown = Character("Dr. Brown", "Dr. Brown is...");
        Character biff = Character("Biff");

        character_names.push_back(marty);
        character_names.push_back(george);
        character_names.push_back(docBrown);
        character_names.push_back(biff);
    }