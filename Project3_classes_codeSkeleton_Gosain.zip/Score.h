// CSCI 1300 Fall 2020
// Author: Vanshita Gosain
// Recitation: 324
// Project 3

#ifndef SCORE_H
#define SCORE_H
#include <string>
using namespace std;

// Purpose of this class is to keep track of the score throught the game.
// Based on the choices that character makes right choice earn more points, somewhat correct earn few, and wrong lose points.

class Score
{
    public:
        // Default
        Score();
        // Parameterized Constructor
        Score(int right, int middle, int wrong, int total);
        int getRight() const;       // Getter
        int getMiddle() const;      // Getter
        int getWrong() const;       // Getter
        int getTotal() const;       // Getter
        int setRight(int right);    // Setter
        int setMiddle(int middle);  // Setter
        int setWrong(int wrong);    // Setter
        int setTotal(int total);    // Setter

    private:
        int Right;
        int Middle;
        int Wrong;
        int Total;
};

#endif




