// CSCI 1300 Fall 2020
// Author: Jasmin Godinez Rivera
// Recitation: 324
// Project 3

#include "Store.h"
#include <string>

using namespace std;

Store::Store(){
    string Item= "";
    double Price= 0;
    const static int size=5;
    string itemArray[5];
    //or string itemArray[size};
 
}
Store::Store(string item, double price){
    Item= item;
    Price=price;
}
string  Store::getItem(){
    return Item;
}
void Store::setItem(string item){
    Item=item;
}
double Store::getPrice(){
    return Price;
}
void Store::setPrice(double price){
    Price=price;
}
 
void showItem(){
    const int n=5;
    string itemsArray[n]={"Coffee", "Shake", "Tea", "Bagel", "Toast"}
 
}
