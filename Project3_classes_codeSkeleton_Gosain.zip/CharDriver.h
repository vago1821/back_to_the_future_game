// CSCI 1300 Fall 2020
// Author: Vanshita Gosain
// Recitation: 324
// Project 3

#ifndef CHARDRIVER_H
#define CHARDRIVER_H
#include "Character.h"
#include <vector>
using namespace std;

// The purpose of this class is to populate the vector name in the Character class.
class CharDriver
{
    public:
        // Default Constructor
        CharDriver();
        // Parameterized Constructor
        CharDriver(string printCharacterMenu, vector<string> characterNames);


    private:
        string printCharMenu;
        vector<string> charNames;
}

#endif