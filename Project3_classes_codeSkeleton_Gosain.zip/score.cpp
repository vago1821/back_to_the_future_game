// CSCI 1300 Fall 2020
// Author: Vanshita Gosain
// Recitation: 324
// Project 3

#include "Score.h"
#include <string>

using namespace std;

Score::Score() {
    Right = 0;
    Middle = 0;
    Wrong = 0;
    Total = 0;
}
Score::Score(int right, int middle, int wrong, int total) {
    Right = right;
    Middle = middle;
    Wrong = wrong;
    Total = total;
}
int Score::getRight() const {
    return Right;
}
int Score::setRight(int right) {
    // beased on choices made in the game add 5 points.
}
int Score::getMiddle() const {
    return Middle;
}
int Score::setMiddle(int middle) {
    // based on choices made in the game add 2 points.
}
int Score::getWrong() const {
    return Wrong;
}
int Score::setWrong(int wrong) {
    // based on choices made subtract 5 points
}
int Score::getTotal() const {
    return Total;
}
int Score::setTotal(int total) {
    // calculate final score
        // add all the right and middle scores, subtract all wrong.
        // if total score is higher than a certain number you survived if not you failed.
}

