// CSCI 1300 Fall 2020
// Author: Vanshita Gosain
// Recitation: 324
// Project 3

#include <iostream>
#include "Character.h"
#include <string>

using namespace std;

Character::Character() // Constructor
{
    charName = {};
    charBackground = "";
} 
Character::Character(vector<string> name, string background) // Parameterized
{
    charName = name;
    charBackground = background;
}
string Character::getcharName()
{
    // display a menu of  character names through code
    // whichever character user chooses is the one getcharName gets and then displays
}
string Character::getcharBackground() const
{
    return charBackground;
}
void Character::setcharName(vector<string> name)
{
    charName = name;
}
void Character::setcharBackground(string background)
{
    charBackground = background;
}
void Character::displayCharacterStory(vector<string> name, string background)
{
    cout << name << " has a background of " << background;
}
