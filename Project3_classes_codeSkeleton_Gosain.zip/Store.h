// CSCI 1300 Fall 2020
// Author: Jasmin Godinez Rivera
// Recitation: 324
// Project 3

#ifndef STORE_H
#define STORE_H

#include <string>
using namespace std;

class Store
{
    private:
    string Item;
    double Price;
    const static int size = 5;
    string itemArray[5];
 
    public:
    // Default constructor
    Store();
    // Parameterize Constructor
    Store(string item, double price);
    string getItem();       // Getter
    void setItem(string);   // Setter
    double getPrice();      // Getter
    void setPrice();        // Setter

};

#endif