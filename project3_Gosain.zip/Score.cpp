// CSCI 1300 Fall 2020
// Author: Vanshita Gosain
// Recitation: 324
// Project 3

#include "Score.h"
#include <string>

using namespace std;

Score::Score() {
    Right = 0;
    Middle = 0;
    Wrong = 0;
    Total = 0;
}
Score::Score(int right, int middle, int wrong, int total=0) {
    Right = right;
    Middle = middle;
    Wrong = wrong;
    Total = total;
}
int Score::getRight() const {
    return Right;
}
int Score::setRight(int right) {
    Right = right;
}
int Score::getMiddle() const {
    return Middle;
}
int Score::setMiddle(int middle) {
    Middle = middle;
}
int Score::getWrong() const {
    return Wrong;
}
int Score::setWrong(int wrong) {
    Wrong = wrong;
}
int Score::getTotal() const {
    return Total;
}
int Score::setTotal(int total) {
    Total = total;
}
void Score::addRightPoints(){
    Total += Right;
}
void Score::addMiddlePoints(){
    Total += Middle;
}
void Score::addWrongPoints(){
    Total += Wrong;
}
int Score::finalScore() { // calculates the total score by adding/ subtracting the amount of points acculuated throughout the game.
    Total = Right + Middle - Wrong;
    return Total;
}


