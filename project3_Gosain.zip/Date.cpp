// CSCI 1300 Fall 2020
// Author: Jazmin Godinez Rivera
// Recitation: 324
// Project 3

#include <iostream>
#include <cstdlib>
#include <ctime>
#include "Date.h"

using namespace std;

Date::Date(int Month, int Day, int Year)
{
    month = Month;
    day = Day;
    year = Year;
}
int Date::setDay(){
    day=rand() %30+1;
    return day;
}
int Date::setMonth(){
    srand((unsigned)time(0));
    month=rand() %12+1;
    return month;
}
int Date::setYear(){
    srand((unsigned)time(0));
    year=rand() %10+1;
    return year;
 
}
 
void Date::printDATE(int MONTH, int DAY, int YEAR){
    cout << "You landed in " << MONTH << "/" << DAY << "/" << YEAR << endl;
}
 