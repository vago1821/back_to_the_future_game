// CSCI 1300 Fall 2020
// Author: Jazmin Godinez Rivera
// Recitation: 324
// Project 3

#ifndef DATE_H
#define DATE_H
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
 
class Date
{
private:
    int day;
    int month;
    int year;
public:
    //These are constructors
    Date(){
        srand(time(NULL));
    }
    Date(int, int, int);
 
    int setDay();
    int setMonth();
    int setYear();
    void printDATE(int, int, int);
 
};

#endif


