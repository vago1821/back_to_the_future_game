// CSCI 1300 Fall 2020
// Author: Vanshita Gosain
// Recitation: 324
// Project 3

#ifndef SCORE_H
#define SCORE_H
#include <string>
using namespace std;

// Purpose of this class is to keep track of the score throught the game.
// Based on the choices that character makes right choice earn more points, somewhat correct earn few, and wrong lose points.

class Score
{
    public:
        // Default
        Score();
        // Parameterized Constructor
        Score(int right, int middle, int wrong, int total);
        int getRight() const;       // Getter
        int getMiddle() const;      // Getter
        int getWrong() const;       // Getter
        int getTotal() const;       // Getter
        int setRight(int right);    // Setter
        int setMiddle(int middle);  // Setter
        int setWrong(int wrong);    // Setter
        int setTotal(int total);    // Setter

        void addRightPoints(); // adds the Right variable points (10) to total
        void addMiddlePoints(); // adds fewer Middle variable points (3) to total
        void addWrongPoints(); // subtracts the Wrong variable points (5) to total
        int finalScore(); // calculates the total points gained/ lost at the end

    private:
        int Right; // the number of points you get for getting a right choice
        int Middle; // the points you get for making the middle choice
        int Wrong;  // the points you get for making the wrong choice
        int Total;  // a running total of all the points you scored in the whole game
};

#endif




